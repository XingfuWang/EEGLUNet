import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Function

# ==========================================================
# EEGLUNet - LU-Decomposed EEG Representation Learning Model
# ==========================================================
# Dear Reviewer,
# Thank you sincerely for taking the time to read, run, and evaluate our code. 😊
# We hope this implementation helps you better understand the model design,
# and that it makes your review experience smoother and more enjoyable.

def symmetric(A):
    return 0.5 * (A + A.t())


class Vectorize(nn.Module):

    def __init__(self, input_size):
        super(Vectorize, self).__init__()
        row_idx, col_idx = np.triu_indices(input_size)
        self.register_buffer('row_idx', torch.LongTensor(row_idx))
        self.register_buffer('col_idx', torch.LongTensor(col_idx))

    def forward(self, input):
        output = input[:, self.row_idx, self.col_idx]
        return output

class TangentSpaceFunction(Function):

    @staticmethod
    def forward(ctx, input):
        ctx.save_for_backward(input)

        output = input.new(input.size(0), input.size(1), input.size(2))
        for k, x in enumerate(input):
            u, s, v = x.svd()
            s.log_()
            output[k] = u.mm(s.diag().mm(u.t()))

        return output

    @staticmethod
    def backward(ctx, grad_output):
        input = ctx.saved_variables
        input = input[0]
        grad_input = None

        if ctx.needs_input_grad[0]:
            eye = input.new(input.size(1))
            eye.fill_(1)
            grad_input = input.new(input.size(0), input.size(1), input.size(1))
            for k, g in enumerate(grad_output):
                x = input[k]
                u, s, v = x.svd()

                g = symmetric(g)

                s_log_diag = s.log().diag()
                s_inv_diag = (1 / s).diag()

                dLdV = 2 * (g.mm(u.mm(s_log_diag)))
                dLdS = s_inv_diag.mm(u.t().mm(g.mm(u)))

                P = s.unsqueeze(1)
                P = P.expand(-1, P.size(0))
                P = P - P.t()
                mask_zero = torch.abs(P) == 0
                P = 1 / P
                P[mask_zero] = 0

                grad_input[k] = 2 * u.mm(P.t() * symmetric(u.t().mm(dLdV))).mm(u.t()) + (u.mm(dLdS)).mm(u.t())

        return grad_input

class TangentSpace_mapping(nn.Module):

    def __init__(self, input_size, vectorize=True):
        super(TangentSpace_mapping, self).__init__()
        self.vectorize = vectorize
        if vectorize:
            self.vec = Vectorize(input_size)

    def forward(self, input):
        output = TangentSpaceFunction.apply(input)
        if self.vectorize:
            output = self.vec(output)

        return output