Dear Reviewer,

Thank you very much for dedicating your time and effort to review our work. 😊
To save your time and ensure a seamless reproduction experience, we provide a fully automated, end-to-end code package — with no need for manual dataset download or preprocessing. All steps, from data acquisition to model training and result saving, are performed automatically！ 😊

Please find below detailed instructions for usage.

This package accompanies the anonymous submission titled:

    "EEGLUNet: Fast and Discriminative EEG Representation Learning in LU-Decomposed Space"

========================
1. Environment Setup
========================

Required environment:

- Python 3.10
- PyTorch 2.2.2 + CUDA 12.1
- numpy==1.24.4
- pandas==2.2.3
- matplotlib==3.9.0
- scikit-learn==1.5.0
- moabb==1.2.0
- braindecode==0.8.1

We recommend installing PyTorch manually before the other dependencies:

    pip install torch==2.2.2 torchvision==0.17.2 torchaudio==2.2.2 --index-url https://download.pytorch.org/whl/cu121

Then install all other packages via:

    pip install -r requirements.txt

========================
2. Datasets
========================

This project supports the following EEG datasets:
- BNCI 2014-001 (~743MB)
- BNCI 2014-002 (~179MB)
- Zhou2016 (~176MB)

Important:  
You do NOT need to download any dataset manually.  
On the first run, the script will automatically download the raw data from the internet.

========================
3. How to Run
========================

To train models on all supported datasets using default settings, simply run:

    python main.py

This will:
- Automatically download and preprocess the data
- Train all models
- Save all results under the `output_folder/` directory

Customizing dataset or model 
To run specific datasets or models, open `main.py` and edit the following two lists by simply uncommenting the corresponding lines. 😄

Example:

dataset_list = [
    'BNCI2014_001',
    # 'BNCI2014_002',
    # 'Zhou2016',
]

model_list = [
    'EEGLUNet',
    # 'CTNet',
    # 'DeepNet',
    ...
]

========================
4. A Final Note of Gratitude
========================

Thank you again for your time and thoughtful review. We hope this package makes your evaluation smoother and more enjoyable.

Wishing you good health and happiness. 🌸
We're happy to connect after the review process. 😄

With gratitude,
The Authors
